import Foundation
import Observation

enum BookLoadState {
    case locked(LockedSummary?)
    case loading(UUID)
    case ready(LoadedBook)
    case failed(AppFailure)
}

@MainActor @Observable
final class LeaderStore {
    private(set) var state: BookLoadState = .locked(nil)
    private enum Access { case locked, authenticating(UUID), unlocked(UUID) }
    private var access: Access = .locked
    private var summary: LockedSummary?
    private var soldierEdits: [UUID: SoldierEditSession] = [:]
    private let authenticator: any RecordAuthenticating
    private var epoch = UUID()
    private var lease: RecordAccessLease?
    private var exportRequest: UUID?
    var isUnlocked: Bool { if case .unlocked = access { true } else { false } }
    var isAuthenticating: Bool { if case .authenticating = access { true } else { false } }
    private(set) var draft = FitnessDraft()
    var operationFailure: AppFailure?
    let draftSave = OwnedOperation()
    private let repository: BookRepository
    private var operations: [UUID: Task<Void, Never>] = [:]
    init(fileURL: URL = URL.applicationSupportDirectory.appending(path: "LeadersBook/records.json"), scorer: AFTScoring, authenticator: any RecordAuthenticating = UnavailableRecordAuthenticator()) {
        self.authenticator = authenticator
        repository = BookRepository(fileURL: fileURL, scorer: scorer)
    }
    var records: BookSnapshot {
        get throws {
            switch state {
            case .ready(let book): book.snapshot
            case .failed(let failure): throw failure
            case .locked: throw RecordAccessError.locked
        case .loading: throw RecordError.recoveryRequired
            }
        }
    }

    var storageWarning: AppFailure? { if case .ready(let book) = state { book.warning } else { nil } }
    var cleanupIssue: RecoveryIssue? {
        if case .ready(let book) = state, case .pending(let issue) = book.cleanup { issue } else { nil }
    }
    func unlock() async throws {
        guard case .locked = access else { throw RecordAccessError.superseded }
        let request = UUID()
        access = .authenticating(request)
        do {
            try await authenticator.authenticate()
            try Task.checkCancellation()
            guard case .authenticating(let active) = access, active == request else { throw RecordAccessError.superseded }
            let book = try await repository.load()
            try Task.checkCancellation()
            guard case .authenticating(let active) = access, active == request else { throw RecordAccessError.superseded }
            epoch = UUID()
            lease = RecordAccessLease()
            access = .unlocked(epoch)
            summary = LockedSummary(soldiers: book.snapshot.soldiers.count, results: book.snapshot.results.count)
            draft = book.snapshot.fitnessDraft
            state = .ready(book)
        } catch {
            if case .authenticating(let active) = access, active == request {
                lock()
                operationFailure = AppFailure("Unlock Records", underlying: error)
            }
            throw error
        }
    }
    func lock() {
        epoch = UUID()
        lease?.revoke(); lease = nil
        access = .locked
        authenticator.cancel()
        exportRequest = nil
        draftSave.cancel()
        for task in operations.values { task.cancel() }
        draft = FitnessDraft()
        soldierEdits = soldierEdits.filter { $0.value.hasChanges }
        operationFailure = nil
        state = .locked(summary)
    }
    private func requireAccess() throws {
        guard case .unlocked = access else { throw RecordAccessError.locked }
    }
    func reload() async {
        do { try requireAccess() }
        catch { operationFailure = AppFailure("Reload Records", underlying: error); return }
        draftSave.cancel()
        let request = UUID()
        let generation = epoch
        state = .loading(request)
        do {
            let book = try await repository.load()
            guard generation == epoch else { return }
            summary = LockedSummary(soldiers: book.snapshot.soldiers.count, results: book.snapshot.results.count)
            guard case .loading(let active) = state, active == request else { return }
            state = .ready(book); draft = book.snapshot.fitnessDraft
        } catch is CancellationError {
            guard generation == epoch else { return }
            guard case .loading(let active) = state, active == request else { return }
            state = .loading(UUID())
        } catch {
            guard generation == epoch else { return }
            guard case .loading(let active) = state, active == request else { return }
            state = .failed(AppFailure("Open Records", underlying: error))
        }
    }
    private func publish(_ book: LoadedBook) {
        guard case .ready(let current) = state, current.snapshot.generation <= book.snapshot.generation else { return }
        summary = LockedSummary(soldiers: book.snapshot.soldiers.count, results: book.snapshot.results.count)
        state = .ready(book)
    }
    func attachmentURL(_ attachment: RecordAttachment) throws -> URL { try requireAccess(); return repository.attachmentURL(attachment) }
    func readAttachment(_ attachment: RecordAttachment) async throws -> ImportedRecordFile {
        try requireAccess()
        let generation = epoch
        let file = try await repository.readAttachment(attachment, permit: accessLease())
        try requireAccess()
        guard generation == epoch else { throw RecordAccessError.superseded }
        return file
    }
    private func requireReady() throws {
        try requireAccess()
        switch state {
        case .ready: return
        case .failed(let failure): throw failure
        case .locked: throw RecordAccessError.locked
        case .loading: throw RecordError.recoveryRequired
        }
    }
    private func accessLease() throws -> RecordAccessLease {
        try requireAccess()
        guard let lease else { preconditionFailure("Unlocked session must own a lease") }
        return lease
    }
    private func execute(_ mutation: BookMutation) async throws -> LoadedBook {
        try requireAccess()
        let generation = epoch
        do {
            let result = try await repository.apply(mutation, permit: accessLease())
            try requireAccess()
            guard generation == epoch else { throw RecordAccessError.superseded }
            publish(result)
            return result
        } catch {
            let status = await repository.currentStatus()
            if generation == epoch, case .ready = state {
                switch status {
                case .ready(let book): publish(book)
                case .failed(let failure): state = .failed(failure)
                case .unopened: break // A concurrent reload owns its loading transition.
                }
            }
            throw error
        }
    }
    private func authenticateExport() async throws -> RecordAccessLease {
        try requireReady()
        guard exportRequest == nil else { throw RecordAccessError.superseded }
        let request = UUID(), generation = epoch
        let permit = try accessLease()
        exportRequest = request
        defer { if exportRequest == request { exportRequest = nil } }
        try await authenticator.authenticateForExport()
        try Task.checkCancellation()
        try requireReady()
        guard generation == epoch, exportRequest == request else { throw RecordAccessError.superseded }
        return permit
    }
    func exportNotes(soldierID: UUID) async throws -> AuthorizedRecordExport {
        let permit = try await authenticateExport()
        try permit.check()
        guard let soldier = try records.soldiers.first(where: { $0.id == soldierID }) else { throw RecordError.missingSoldier }
        return AuthorizedRecordExport(content: .notes(soldier.notes))
    }
    func exportCertificate(_ attachment: RecordAttachment) async throws -> AuthorizedRecordExport {
        let permit = try await authenticateExport()
        try permit.check()
        guard try records.attachments.contains(attachment) else { throw RecordError.invalidAttachment }
        let file = try await readAttachment(attachment)
        try permit.check()
        return AuthorizedRecordExport(content: .certificate(file))
    }
    /// Scene lifecycle cleanup is permitted while locked and cannot recreate a draft.
    func disconnectEditorWindow(_ window: UUID) { soldierEdits[window] = nil }
    func beginSoldierEdit(_ soldier: SoldierDraft, window: UUID) throws -> SoldierEditSession {
        if let existing = try restoreSoldierEdit(window: window) { return existing }
        let edit = SoldierEditSession(id: UUID(), window: window, original: soldier,
                                      soldier: soldier, files: [], permit: try accessLease())
        soldierEdits[window] = edit
        return edit
    }
    func restoreSoldierEdit(window: UUID) throws -> SoldierEditSession? {
        try requireReady()
        guard let retained = soldierEdits[window] else { return nil }
        let restored = SoldierEditSession(id: retained.id, window: window, original: retained.original,
                                         soldier: retained.soldier, files: retained.files, permit: try accessLease())
        soldierEdits[window] = restored
        return restored
    }
    func updateSoldierEdit(_ edit: SoldierEditSession) throws {
        try requireReady()
        try edit.permit.check()
        guard let retained = soldierEdits[edit.window], retained.id == edit.id,
              retained.original == edit.original, retained.original.id == edit.soldier.id,
              edit.soldier.revision == retained.original.revision else { throw RecordError.conflict }
        soldierEdits[edit.window] = edit
    }
    func discardSoldierEdit(_ edit: SoldierEditSession) throws {
        try requireReady()
        try edit.permit.check()
        guard let retained = soldierEdits[edit.window] else { return } // Already saved/closed is an idempotent outcome.
        guard retained.id == edit.id else { throw RecordError.conflict }
        soldierEdits[edit.window] = nil
    }
    func saveSoldierEdit(_ edit: SoldierEditSession) async throws {
        try updateSoldierEdit(edit)
        try await saveSoldier(edit.soldier, importing: edit.files)
        try discardSoldierEdit(edit)
    }
    func saveSoldier(_ input: SoldierDraft, importing files: [ImportedRecordFile] = []) async throws {
        try requireReady()
        let soldier = try Soldier(draft: input)
        _ = try await execute(.saveSoldier(soldier, expectedRevision: input.revision, files))
    }
    func deleteSoldier(id: UUID) async throws {
        try requireReady()
        _ = try await execute(.deleteSoldier(id))
        if draft.soldierID == id { var updated = draft; updated.soldierID = nil; updateDraft(updated) }
    }
    func saveDraft(_ input: FitnessDraft) async throws {
        try requireReady()
        try input.validateStructure()
        _ = try await execute(.saveDraft(input))
    }
    func updateDraft(_ input: FitnessDraft) {
        do { try requireAccess(); try input.validateStructure() }
        catch { operationFailure = AppFailure("Validate Calculator Draft", underlying: error); return }
        draft = input
        draftSave.start("Save Calculator Draft") { [self] in
            try await Task.sleep(for: .milliseconds(250))
            try Task.checkCancellation()
            try await saveDraft(input)
        }
    }
    func saveResult() async throws {
        try requireReady()
        draftSave.cancel()
        let input = draft
        let result = try await execute(.saveResult(input, UUID()))
        if case .ready(let current) = state, current.snapshot.generation == result.snapshot.generation {
            if draft == input { draft = result.snapshot.fitnessDraft }
            else { var latest = draft; latest.tool = .history; updateDraft(latest) }
        }
    }
    func deleteResults(ids: Set<UUID>) async throws { try requireReady(); _ = try await execute(.deleteResults(ids)) }
    func recoverAttachments() async throws {
        try requireAccess()
        let generation = epoch
        do {
            let book = try await repository.recoverPending()
            try requireAccess()
            guard generation == epoch else { throw RecordAccessError.superseded }
            publish(book)
        }
        catch is CancellationError { throw CancellationError() }
        catch {
            if generation == epoch { state = .failed(AppFailure("Recover Attachments", underlying: error)) }
            throw error
        }
    }
    /// App-lifetime UI mutation owner. These operations are not automatically retried.
    func submit(_ operation: String, work: @escaping @MainActor () async throws -> Void) {
        let id = UUID()
        let generation = epoch
        operations[id] = Task { [self] in
            defer { operations[id] = nil }
            do { try requireAccess(); try Task.checkCancellation(); try await work() }
            catch is CancellationError { /* App-lifetime shutdown owns this cancellation. */ }
            catch {
                let failure = AppFailure(operation, underlying: error)
                if generation == epoch { operationFailure = failure }
                // execute() already synchronized the authoritative repository outcome.
            }
        }
    }
    isolated deinit { for operation in operations.values { operation.cancel() } }
}
